# Daymark — To-do List Application

A responsive client-side task manager built with semantic HTML, modern CSS, and vanilla JavaScript.

## Run locally
1. Download and extract `todo_list_app.zip`.
2. Open the `todo_list_app` folder.
3. Double-click `index.html` to open it in a modern browser.
4. For development, open the folder in VS Code and use the Live Server extension.

No npm install, framework, server, or build process is required.

## Features
- Create tasks with High, Medium, or Low priority.
- Read/render current task state dynamically.
- Update tasks by editing title/priority or toggling completion.
- Delete individual tasks or clear completed tasks.
- Persist tasks with `window.localStorage` across reloads.
- All, Active, and Completed filters in sidebar and task tabs.
- Live search and newest/oldest sorting.
- Light/dark theme persisted separately in local storage.
- Event delegation for task edit/delete and completion events.
- Responsive desktop, tablet, and mobile layouts.
- Accessible labels, focus states, status messages, and reduced-motion support.

## Files
- `index.html` — semantic page structure
- `style.css` — theme variables, layout, visual components, responsive media queries
- `script.js` — CRUD logic, state, rendering, filters, local storage, delegated events

## Privacy
Tasks are saved in this browser on this device. They are not uploaded to a server. Clearing browser site data may remove them.

## Test checklist
1. Add a task and refresh; it should remain.
2. Add tasks with different priorities.
3. Toggle a task complete and back to active.
4. Edit its title and priority.
5. Delete a task.
6. Try All, Active, and Completed filters.
7. Search by part of a title.
8. Switch sort order.
9. Clear completed tasks.
10. Change theme and refresh.
11. Resize the browser to phone, tablet, and desktop widths.
