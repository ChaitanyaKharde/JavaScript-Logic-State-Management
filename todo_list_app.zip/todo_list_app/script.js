(() => {
  "use strict";
  const STORAGE_KEY = "daymark-tasks-v1";
  const THEME_KEY = "daymark-theme-v1";
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const els = {
    form: $("#taskForm"), taskInput: $("#taskInput"), priorityInput: $("#priorityInput"),
    taskList: $("#taskList"), emptyState: $("#emptyState"), emptyTitle: $("#emptyTitle"),
    emptyMessage: $("#emptyMessage"), search: $("#searchInput"), sortButton: $("#sortButton"),
    sortLabel: $("#sortLabel"), clearCompleted: $("#clearCompleted"), themeToggle: $("#themeToggle"),
    themeIcon: $("#themeIcon"), editDialog: $("#editDialog"), editForm: $("#editForm"),
    editTaskInput: $("#editTaskInput"), editPriorityInput: $("#editPriorityInput"),
    closeDialog: $("#closeDialog"), cancelEdit: $("#cancelEdit"), toast: $("#toast")
  };
  let tasks = loadTasks(), currentFilter = "all", sortNewestFirst = true, editingId = null, toastTimer;

  function loadTasks() {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      if (!Array.isArray(data)) return [];
      return data.filter(t => t && typeof t.id === "string" && typeof t.title === "string" && typeof t.completed === "boolean")
        .map(t => ({ id:t.id, title:t.title.slice(0,160), completed:t.completed,
          priority:["high","medium","low"].includes(t.priority) ? t.priority : "medium",
          createdAt:Number(t.createdAt)||Date.now(), updatedAt:Number(t.updatedAt)||Number(t.createdAt)||Date.now(),
          completedAt:Number(t.completedAt)||null }));
    } catch (e) { console.warn("Could not load saved tasks:", e); return []; }
  }
  function saveTasks() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)); return true; }
    catch (e) { console.error("Could not save tasks:", e); showToast("Unable to save. Check browser storage settings."); return false; }
  }
  function makeId() { return crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
  function formatDate(time) { return new Intl.DateTimeFormat(undefined,{month:"short",day:"numeric"}).format(new Date(time)); }
  function escapeText(value) { return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function getVisibleTasks() {
    const q = els.search.value.trim().toLocaleLowerCase();
    return tasks.filter(t => currentFilter==="all" || (currentFilter==="active"&&!t.completed) || (currentFilter==="completed"&&t.completed))
      .filter(t=>t.title.toLocaleLowerCase().includes(q)).sort((a,b)=>sortNewestFirst?b.createdAt-a.createdAt:a.createdAt-b.createdAt);
  }
  function render() {
    const total=tasks.length, completed=tasks.filter(t=>t.completed).length, active=total-completed, visible=getVisibleTasks();
    $("#allCount").textContent=total; $("#activeCount").textContent=active; $("#completedCount").textContent=completed;
    $("#tabAll").textContent=total; $("#tabActive").textContent=active; $("#tabCompleted").textContent=completed;
    $("#totalStat").textContent=total; $("#activeStat").textContent=active; $("#completedStat").textContent=completed;
    $("#visibleCount").textContent=visible.length; $("#footerSummary").textContent=`${active} task${active===1?"":"s"} left`;
    const percent=total?Math.round(completed/total*100):0;
    $("#focusPercent").textContent=`${percent}%`; $("#focusProgress").style.width=`${percent}%`;
    els.clearCompleted.disabled=completed===0;
    $$(".side-link,.filter-tab").forEach(b=>{const on=b.dataset.filter===currentFilter;b.classList.toggle("active",on);if(b.classList.contains("filter-tab"))b.setAttribute("aria-pressed",String(on));});
    els.taskList.innerHTML=visible.map(t=>`<article class="task-row ${t.completed?"is-completed":""}" data-task-id="${escapeText(t.id)}">
      <input class="task-check" type="checkbox" data-action="toggle" aria-label="${t.completed?"Mark as active":"Mark as completed"}: ${escapeText(t.title)}" ${t.completed?"checked":""}>
      <div class="task-main"><span class="task-title">${escapeText(t.title)}</span><div class="task-meta"><span>Added ${formatDate(t.createdAt)}</span>${t.completedAt?`<span>· Completed ${formatDate(t.completedAt)}</span>`:""}</div></div>
      <span class="task-priority priority-${t.priority}">${t.priority[0].toUpperCase()+t.priority.slice(1)} priority</span>
      <div class="task-actions"><button type="button" class="task-action" data-action="edit" aria-label="Edit task: ${escapeText(t.title)}" title="Edit task">✎</button><button type="button" class="task-action delete" data-action="delete" aria-label="Delete task: ${escapeText(t.title)}" title="Delete task">×</button></div></article>`).join("");
    const has=visible.length>0; els.emptyState.classList.toggle("show",!has); els.taskList.hidden=!has;
    if(!has){if(els.search.value.trim()){els.emptyTitle.textContent="No matches found.";els.emptyMessage.textContent="Try another search term or switch your filter.";}
      else if(currentFilter==="completed"){els.emptyTitle.textContent="Nothing completed yet.";els.emptyMessage.textContent="Finish a task and it will show up here. You've got this.";}
      else if(currentFilter==="active"){els.emptyTitle.textContent="All caught up!";els.emptyMessage.textContent="There are no active tasks. Enjoy the breathing room.";}
      else{els.emptyTitle.textContent="A fresh start.";els.emptyMessage.textContent="Add your first task above and turn your plans into progress.";}}
  }
  function addTask(title,priority){const name=title.trim();if(!name){els.taskInput.focus();return;}const now=Date.now();tasks.unshift({id:makeId(),title:name,completed:false,priority,createdAt:now,updatedAt:now,completedAt:null});saveTasks();currentFilter="all";els.search.value="";els.taskInput.value="";render();els.taskInput.focus();showToast("Task added — nice start!");}
  function toggleTask(id){const t=tasks.find(x=>x.id===id);if(!t)return;t.completed=!t.completed;t.updatedAt=Date.now();t.completedAt=t.completed?Date.now():null;saveTasks();render();showToast(t.completed?"Task completed. Well done!":"Task moved back to active.");}
  function deleteTask(id){if(!tasks.some(t=>t.id===id))return;tasks=tasks.filter(t=>t.id!==id);saveTasks();render();showToast("Task deleted.");}
  function openEditDialog(id){const t=tasks.find(x=>x.id===id);if(!t)return;editingId=id;els.editTaskInput.value=t.title;els.editPriorityInput.value=t.priority;if(els.editDialog.showModal)els.editDialog.showModal();else els.editDialog.setAttribute("open","");setTimeout(()=>els.editTaskInput.focus(),0);}
  function closeEditDialog(){if(els.editDialog.close&&els.editDialog.open)els.editDialog.close();else els.editDialog.removeAttribute("open");editingId=null;}
  function updateTask(){const title=els.editTaskInput.value.trim();if(!title){els.editTaskInput.focus();return;}const t=tasks.find(x=>x.id===editingId);if(!t)return closeEditDialog();t.title=title;t.priority=els.editPriorityInput.value;t.updatedAt=Date.now();saveTasks();closeEditDialog();render();showToast("Changes saved.");}
  function setFilter(filter){if(!["all","active","completed"].includes(filter))return;currentFilter=filter;render();}
  function clearCompleted(){const n=tasks.filter(t=>t.completed).length;if(!n)return;tasks=tasks.filter(t=>!t.completed);saveTasks();render();showToast(`${n} completed task${n===1?"":"s"} cleared.`);}
  function showToast(message){els.toast.textContent=message;els.toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>els.toast.classList.remove("show"),2400);}
  function applyTheme(theme){document.documentElement.dataset.theme=theme;const light=theme==="light";els.themeIcon.textContent=light?"☾":"☼";els.themeToggle.setAttribute("aria-label",light?"Switch to dark theme":"Switch to light theme");els.themeToggle.title=light?"Switch to dark theme":"Switch to light theme";const meta=$('meta[name="theme-color"]');if(meta)meta.content=light?"#f6f7fb":"#151620";}

  // CREATE
  els.form.addEventListener("submit",e=>{e.preventDefault();addTask(els.taskInput.value,els.priorityInput.value);});
  // READ / FILTER / SEARCH
  $$(".side-link,.filter-tab").forEach(b=>b.addEventListener("click",()=>setFilter(b.dataset.filter)));
  els.search.addEventListener("input",render);
  // UPDATE + DELETE via event delegation: dynamically rendered task buttons need no individual listeners.
  els.taskList.addEventListener("click",e=>{const b=e.target.closest("[data-action]");if(!b)return;const row=b.closest("[data-task-id]");if(!row)return;if(b.dataset.action==="edit")openEditDialog(row.dataset.taskId);if(b.dataset.action==="delete")deleteTask(row.dataset.taskId);});
  els.taskList.addEventListener("change",e=>{const box=e.target.closest('[data-action="toggle"]');if(!box)return;const row=box.closest("[data-task-id]");if(row)toggleTask(row.dataset.taskId);});
  els.editForm.addEventListener("submit",e=>{e.preventDefault();updateTask();});
  els.closeDialog.addEventListener("click",closeEditDialog);els.cancelEdit.addEventListener("click",closeEditDialog);
  els.editDialog.addEventListener("click",e=>{if(e.target===els.editDialog)closeEditDialog();});
  els.clearCompleted.addEventListener("click",clearCompleted);
  els.sortButton.addEventListener("click",()=>{sortNewestFirst=!sortNewestFirst;els.sortLabel.textContent=sortNewestFirst?"Newest":"Oldest";render();});
  els.themeToggle.addEventListener("click",()=>{const next=document.documentElement.dataset.theme==="light"?"dark":"light";applyTheme(next);try{localStorage.setItem(THEME_KEY,next);}catch(e){}});
  const now=new Date();$("#dateLabel").textContent=new Intl.DateTimeFormat(undefined,{weekday:"long",month:"long",day:"numeric"}).format(now).toUpperCase();$("#currentYear").textContent=now.getFullYear();
  let theme="light";try{const stored=localStorage.getItem(THEME_KEY);if(stored==="light"||stored==="dark")theme=stored;}catch(e){}applyTheme(theme);render();
})();
